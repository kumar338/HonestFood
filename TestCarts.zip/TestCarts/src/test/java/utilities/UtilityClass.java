package utilities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class UtilityClass {
	WebDriver driver;
	
	public UtilityClass(WebDriver driver){
		this.driver= driver;
		
	}
	
	
	public void scroll(){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
	}
	
}

package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RestSelect {

	WebDriver driver;
	WebElement button_Change_Restaurant;
	WebElement Mamacita;
	WebElement button_Schalen_Menu;
	WebElement button_Schalen_Menu_addition;
	WebElement label_Schalen_Menu_addition_Knuspriger_Halloumi;
	WebElement label_Schalen_Menu_addition_Cremiger_Hummus;
	WebElement tf_addspecialinstruction;
	WebElement button_Add_to_cart;
	WebElement tf_enter_address;
	
	
	public RestSelect(WebDriver driver){
		this.driver = driver;
		
		button_Change_Restaurant = driver.findElement(By.xpath("*[@id='header-center']/div[2]/div[2]/a/span"));
		Mamacita = driver.findElement(By.xpath("//*[@id='header-center']/div[2]/ul[2]/li[5]/a"));
		button_Schalen_Menu = driver.findElement(By.xpath("//button[text()=' Schalen Men� ']"));
		button_Schalen_Menu_addition= driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/div/section/div/div[2]/div/div[2]/form/div/div/div[2]/div[1]/div/div[1]/span/input"));
		label_Schalen_Menu_addition_Knuspriger_Halloumi = driver.findElement(By.xpath("//div[text()='Knuspriger Halloumi']"));
		label_Schalen_Menu_addition_Cremiger_Hummus = driver.findElement(By.xpath("//div[text()='Cremiger Hummus']"));
		tf_addspecialinstruction = driver.findElement(By.xpath("//*[@id='special-instructions']"));
		button_Add_to_cart = driver.findElement(By.xpath("//button[@name='In den Warenkorb']"));
		tf_enter_address = driver.findElement(By.xpath("//input[@id='address-input']"));
	}
	
	
	
	
	public void click_button_Schalen_Menu(){
		button_Schalen_Menu.click();
	}
	public void click_button_Schalen_Menu_addition(){
		button_Schalen_Menu_addition.click();
	}
	
	public void click_label_Schalen_Menu_addition_Knuspriger_Halloumi(){
		label_Schalen_Menu_addition_Knuspriger_Halloumi.click();
	}
	
	public void click_label_Schalen_Menu_addition_Cremiger_Hummus(){
		label_Schalen_Menu_addition_Cremiger_Hummus.click();
	}
	
	public void add_Special_Instructions(String msg){
		tf_addspecialinstruction.sendKeys(msg);
	}
	
	public void click_button_Add_to_cart(){
		button_Add_to_cart.click();
	}
	
	public void add_tf_enter_address(){
		tf_enter_address.sendKeys("Semperstra�e 44, 1180 Wien, Austria");
	}
	
	public void click_button_Change_Restaurant(){
		button_Change_Restaurant.click();
	}
	
	public void click_Mamacita(){
		Mamacita.click();
	}
	
}

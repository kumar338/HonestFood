package Actions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import pageobject.HomePage;
import utilities.UtilityClass;

public class HomeActions {
	WebDriver driver;
	
	
	@BeforeSuite
	public void initializedriver(){
		
		System.setProperty("webdriver.ie.driver", "C:\\Users\\ashwani\\eclipse-workspace\\TestCarts\\src\\test\\resources\\runnables\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.get("https://clubkitchen.at/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	@Test
	public void goToCart() throws InterruptedException{	
		HomePage hp = new HomePage(driver);
		RestSelect rs = new RestSelect(driver);
		UtilityClass uc = new UtilityClass(driver);
		WebDriverWait wait = new WebDriverWait(driver,10);
		hp.click_button_ToTheMenu();
		Thread.sleep(2000);
		//switch to the overlay screen and enter address and click go to menu
		rs.add_tf_enter_address();
		
		//go to change the rest button and select mamacita
		
		rs.click_button_Change_Restaurant();
		rs.click_Mamacita();
		
		//scroll page to select product
		uc.scroll();
		
		//select first product
		rs.click_button_Schalen_Menu();
		Thread.sleep(2000);
		//switch to overlay window and select type with additional selection(extras)
		rs.click_button_Schalen_Menu_addition();
		rs.click_label_Schalen_Menu_addition_Knuspriger_Halloumi();
		rs.click_label_Schalen_Menu_addition_Cremiger_Hummus();
		rs.add_Special_Instructions("Add extra cheese");
		rs.click_button_Add_to_cart();
		
		
	}
	
	
	@AfterSuite
	public void teardown(){	
		driver.close();	
	}
		
		

	
	
	
}

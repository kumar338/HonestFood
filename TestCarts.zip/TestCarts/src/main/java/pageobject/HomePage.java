package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	
	WebDriver driver;
	WebElement button_ToTheMenu; 
	

	
	public HomePage(WebDriver driver){	
		this.driver = driver;
		
		button_ToTheMenu = driver.findElement(By.xpath("//span[text()='Zur Speisekarte']"));
		
		
	}
	
	public void click_button_ToTheMenu(){
		button_ToTheMenu.click();
	}
	

	
	

}
